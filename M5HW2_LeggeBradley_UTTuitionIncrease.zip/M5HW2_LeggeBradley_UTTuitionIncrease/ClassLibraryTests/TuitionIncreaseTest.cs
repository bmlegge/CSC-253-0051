﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleUI;
using Xunit;

namespace ClassLibraryTests
{
    public class TuitionIncreaseTest
    {
        [Fact]
        public static void Add_LoopShouldIncreaseTuition()
        {
            double expected = 6000;

            double acutal = Program.TuitionIncrease(6000);
        }
    }
}
