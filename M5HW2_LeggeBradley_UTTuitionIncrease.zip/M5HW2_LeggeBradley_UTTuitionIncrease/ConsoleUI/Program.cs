﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Program
    {
        static void Main(string[] args)
        {
            double tuition = 6000;
            TuitionIncrease(tuition);
        }
        
        public static void TuitionIncrease(double tuition)
        { 
            for(int i = 0; i <= 5; i++)
            {
                Console.WriteLine($"Tuition for year {i + 1} is ${tuition}.");
                tuition = tuition + (tuition * .02);
            }
            Console.ReadLine();
        }
    }
}
