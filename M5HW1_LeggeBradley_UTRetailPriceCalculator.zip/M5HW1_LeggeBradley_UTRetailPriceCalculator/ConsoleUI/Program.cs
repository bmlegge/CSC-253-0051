﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            decimal wholeSalePrice;
            decimal markUpPer;
            decimal retailPrice;

            Console.Write("Enter an item's wholesale cost: > ");
            wholeSalePrice = DecimalParse(Console.ReadLine());

            Console.Write("Enter the markup percentage as a whole number (ex. 50): > ");
            markUpPer = DecimalParse(Console.ReadLine());

            retailPrice = CalculateRetail(wholeSalePrice, markUpPer);

            Console.WriteLine($"The items wholesale cost is ${wholeSalePrice} with a markup amount of " +
                              $"{markUpPer}% for a retail price of ${retailPrice}.");
            Console.ReadLine();
        }

        public static decimal CalculateRetail(decimal wholeSale, decimal markUp)
        {
            decimal retailPrice;

            retailPrice = (wholeSale * (markUp / 100)) + wholeSale;

            return retailPrice;
        }

        public static decimal DecimalParse(string input)
        {
            decimal output = 0m;

            while (!decimal.TryParse(input, out output))
            {
                Console.Write("Invalid input! Enter a number: > ");
                input = Console.ReadLine();
            }
            return output;
        }
    }
}
