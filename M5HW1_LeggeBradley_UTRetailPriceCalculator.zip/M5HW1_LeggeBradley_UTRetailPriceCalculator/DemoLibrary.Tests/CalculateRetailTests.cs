﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleUI;
using Xunit;

namespace DemoLibrary.Tests
{
    public class CalculateRetailTests
    {
        [Fact]
        public void Add_RetailPriceShouldCalculate()
        {
            decimal expected = 10;

            decimal actual = Program.CalculateRetail(5, 100);

            Assert.Equal(expected, actual);
        }
    }
}
